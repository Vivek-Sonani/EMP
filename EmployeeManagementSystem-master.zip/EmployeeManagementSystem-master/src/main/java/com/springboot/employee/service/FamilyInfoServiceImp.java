package com.springboot.employee.service;

import java.util.List;

import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.springboot.employee.event.FamilyInfoCreatedEvent;
import com.springboot.employee.event.FamilyInfoDeletedEvent;
import com.springboot.employee.event.FamilyInfoUpdatedEvent;
import com.springboot.employee.model.Employee;
import com.springboot.employee.model.FamilyInfo;
import com.springboot.employee.repository.EmployeeRepository;
import com.springboot.employee.repository.FamilyInfoRepository;

@Service
@Transactional(propagation = Propagation.MANDATORY)
public class FamilyInfoServiceImp implements FamilyInfoService {

	@Autowired
	private FamilyInfoRepository familyInfoRepository;

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	@Autowired
	private FamilyInfoEsService familyInfoEsService;
	
	@Autowired
	private ApplicationEventPublisher applicationEventPublisher;
	
	@Autowired
	private EntityManager entityManager;

	@Override
	public FamilyInfo addFamilyInfo(FamilyInfo familyInfo) {
		System.out.println("Implementation starting..");
		Employee e = familyInfo.getEmployee();
		System.out.println(e);
		Employee e1 = employeeRepository.findById(e.getEmployId()).get();
		System.out.println(e1);
		familyInfo.setEmployee(e1);
		System.out.println(familyInfo);
		// Optional<Employee> e1=employeeRepository.findById(e.getEmployId());
		FamilyInfo f = familyInfoRepository.save(familyInfo);
		//familyInfoEsService.addFamilyinfo(familyInfo);
		FamilyInfoCreatedEvent familyInfoCreatedEvent = new FamilyInfoCreatedEvent(familyInfo.getEmployee().getEmployId());
		applicationEventPublisher.publishEvent(familyInfoCreatedEvent);
		
		System.out.println("saved successfully....");
		return dozerBeanMapper.map(f, FamilyInfo.class, "family-info-basic");
	}

	@Override
	public FamilyInfo updateFamilyInfo(FamilyInfo familyInfo) {
		List<FamilyInfo> familyList = familyInfoRepository.findByEmployeeEmployId(familyInfo.getEmployee().getEmployId());
		Optional<FamilyInfo> familyOptional = familyList.stream().filter(f -> f.getId().equals(familyInfo.getId())).findFirst();
		//if (family.isPresent()) {
		//Optional<FamilyInfo> familyOptional = familyInfoRepository.findById(familyInfo.getId());
		if (!familyOptional.isPresent()) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
		} else {
			FamilyInfo f = familyOptional.get();
			f.setName(familyInfo.getName());
			f.setDob(familyInfo.getDob());
			f.setOccupation(familyInfo.getOccupation());
			f.setRelationship(familyInfo.getRelationship());

			FamilyInfo family = familyInfoRepository.save(f);
			//familyInfoEsService.updateFamilyInfo(family);
			FamilyInfoUpdatedEvent familyInfoUpdatedEvent = new FamilyInfoUpdatedEvent(familyInfo.getEmployee().getEmployId());
			applicationEventPublisher.publishEvent(familyInfoUpdatedEvent);
			System.out.println("Updated successfully....");
			return dozerBeanMapper.map(family, FamilyInfo.class, "family-info-basic");

		}
	}

	@Override
	public FamilyInfo getFamilyInfo(Integer id) {
		Optional<FamilyInfo> f = familyInfoRepository.findById(id);
		if (f.isPresent()) {
			FamilyInfo familyInfo = f.get();
			//familyInfoEsService.getFamilyInfo(id);
			return familyInfo;
		} else {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	public List<FamilyInfo> getByEmployeeId(Integer employeeId) {
		List<FamilyInfo> familyList = familyInfoRepository.findByEmployeeEmployId(employeeId);
		// System.out.println(e);
		// familyInfoRepository.findAllById(familyInfo.getId());
		System.out.println(familyList);
		//familyInfoEsService.getByEmployeeId(employeeId);
		return familyList.stream().map(e -> dozerBeanMapper.map(e, FamilyInfo.class, "family-info-basic"))
				.collect(Collectors.toList());
	}

	@Override
	public void removeFamilyInfo(Integer id, Integer employeeId) {
		List<FamilyInfo> familyList = familyInfoRepository.findByEmployeeEmployId(employeeId);
		Optional<FamilyInfo> family = familyList.stream().filter(f -> f.getId().equals(id)).findFirst();
		if (family.isPresent()) {
			familyInfoRepository.deleteById(id);
			entityManager.flush();
			FamilyInfoDeletedEvent familyInfoDeletedEvent = new FamilyInfoDeletedEvent(employeeId);
			applicationEventPublisher.publishEvent(familyInfoDeletedEvent);
		} else
		{
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST);

		}
		System.out.println("deleted successfully...");

	}
}
