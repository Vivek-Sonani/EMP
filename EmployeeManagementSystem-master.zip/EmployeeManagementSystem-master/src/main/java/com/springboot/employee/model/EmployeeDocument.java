package com.springboot.employee.model;

import java.util.Date;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Document(indexName = "employee_index")
public class EmployeeDocument {
	@Id
	@Field(type = FieldType.Integer)
	Integer id;

	@Field(type = FieldType.Text)
	String firstname;

	@Field(type = FieldType.Text)
	String middlename;

	@Field(type = FieldType.Text)
	String lastname;

	// @Length
	@Field(type = FieldType.Text)
	String email;

	@Field(type = FieldType.Text)
	String position;

	@Field(type = FieldType.Integer)
	int contactNo;

	@Field(type = FieldType.Float)
	Float salary;

	@CreatedDate
	@Temporal(TemporalType.TIMESTAMP)
	@Field(type = FieldType.Date, format = DateFormat.basic_date_time)
	private Date createdDate;

	@LastModifiedDate
	@Temporal(TemporalType.TIMESTAMP)
	@Field(type = FieldType.Date, format = DateFormat.basic_date_time)
	private Date modifiedDate;

	@CreatedBy
	@Field(type = FieldType.Text)
	private String createdBy;

	@LastModifiedBy
	@Field(type = FieldType.Text)
	private String modifiedBy;

	@OneToOne(mappedBy = "employee", fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private Address address;

	@JsonManagedReference
	@OneToMany(mappedBy = "employee", fetch = FetchType.LAZY)
	private List<FamilyInfo> familyInfo;

	public EmployeeDocument(Employee employee) {
		this.id = employee.getEmployId();
		this.firstname = employee.getFirstname();
		this.middlename = employee.getMiddlename();
		this.lastname = employee.getFirstname();
		this.position = employee.getPosition();
		this.email = employee.getEmail();
		this.contactNo = employee.getContactNo();
		this.salary = employee.getSalary();
		this.createdBy = employee.getCreatedBy();
		this.createdDate = employee.getCreatedDate();
		this.modifiedBy = employee.getModifiedBy();
		this.modifiedDate = employee.getModifiedDate();
	}

	public List<FamilyInfo> getFamilyInfo() {
		return familyInfo;
	}

	public void setFamilyInfo(List<FamilyInfo> familyInfo) {
		this.familyInfo = familyInfo;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public EmployeeDocument() {
		//this.setEmployId((int) Math.random());
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer employId) {
		this.id = employId;
	}

	public Float getSalary() {
		return salary;
	}

	public void setSalary(Float salary) {
		this.salary = salary;
	}

	public int getContactNo() {
		return contactNo;
	}

	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getMiddlename() {
		return middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	@Override
	public String toString() {
		return "Employee [employId=" + id + ", firstname=" + firstname + ", middlename=" + middlename
				+ ", lastname=" + lastname + ", email=" + email + ", position=" + position + ", contactNo=" + contactNo
				+ ", salary=" + salary + ", createdBy=" + createdBy + ", modifiedBy=" + modifiedBy + "]";
	}

}
