package com.springboot.employee.service;

import com.springboot.employee.model.Employee;
import com.springboot.employee.model.EmployeeDocument;

public interface EmployeeEsService {
	EmployeeDocument addEmployee(Employee employee);

}
