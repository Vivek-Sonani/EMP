package com.springboot.employee.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.elasticsearch.client.ClientConfiguration;
import org.springframework.data.elasticsearch.client.elc.ElasticsearchConfiguration;
import org.springframework.data.elasticsearch.client.elc.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.config.EnableElasticsearchAuditing;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.repository.config.EnableElasticsearchRepositories;

@Configuration
@EnableElasticsearchRepositories(basePackages = "com.springboot.employee.repository")
@EnableElasticsearchAuditing
public class MyClientEsConfig extends ElasticsearchConfiguration {

	@Bean
	@Override
	public ClientConfiguration clientConfiguration() {
		return ClientConfiguration.builder().connectedTo("localhost:9200").build();

	}

//	@Bean
//	public ElasticsearchOperations elasticsearchTemplate() {
//		// You need to provide the Elasticsearch client and other necessary
//		// configurations here
//		// For example, using the RestHighLevelClient
//		// Replace "localhost" and 9200 with your Elasticsearch server details
//		return new ElasticsearchTemplate(elasticsearchClient());
//	}
}
