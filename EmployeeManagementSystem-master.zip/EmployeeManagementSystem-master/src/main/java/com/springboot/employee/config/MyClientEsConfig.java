package com.springboot.employee.config;

import org.springframework.context.annotation.Bean;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.elasticsearch.client.ClientConfiguration;
import org.springframework.data.elasticsearch.client.elc.ElasticsearchConfiguration;
import org.springframework.data.elasticsearch.config.EnableElasticsearchAuditing;
import org.springframework.data.elasticsearch.repository.config.EnableElasticsearchRepositories;

@Configuration
@EnableElasticsearchRepositories
@EnableElasticsearchAuditing
public class MyClientEsConfig extends ElasticsearchConfiguration {

	@Bean
	@Override
	public ClientConfiguration clientConfiguration() {
		return ClientConfiguration.builder().connectedTo("localhost:9200").build();
	}
	// @SuppressWarnings("deprecation")
//	@Bean
//	    public RestHighLevelClient client() {
//	        ClientConfiguration clientConfiguration 
//	            = ClientConfiguration.builder()
//	                .connectedTo("localhost:9200")
//	                .build();
//	 
//	        return RestClients.create(clientConfiguration).rest();
//	    }
//	 
//	    @Bean
//	    public ElasticsearchOperations elasticsearchTemplate() {
//	        return new ElasticsearchRestTemplate(client());
//	    }

}
