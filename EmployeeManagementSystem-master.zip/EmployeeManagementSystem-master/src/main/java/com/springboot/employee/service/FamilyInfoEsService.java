package com.springboot.employee.service;

import com.springboot.employee.model.FamilyInfo;
import com.springboot.employee.model.FamilyInfoDocument;

public interface FamilyInfoEsService {

	FamilyInfoDocument addFamilyinfo(FamilyInfo familyInfo);

}
