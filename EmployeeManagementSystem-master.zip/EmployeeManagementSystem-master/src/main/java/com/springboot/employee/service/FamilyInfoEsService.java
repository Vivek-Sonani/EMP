package com.springboot.employee.service;

import java.util.List;

import com.springboot.employee.model.FamilyInfo;
import com.springboot.employee.model.FamilyInfoDocument;

public interface FamilyInfoEsService {

	FamilyInfoDocument addFamilyinfo(FamilyInfo familyInfo);

	FamilyInfoDocument updateFamilyInfo(FamilyInfo familyInfo);

	FamilyInfoDocument getFamilyInfo(Integer id);

	List<FamilyInfoDocument> getByEmployeeId(Integer employeeId);

	void removeFamilyInfo(Integer id);

}
