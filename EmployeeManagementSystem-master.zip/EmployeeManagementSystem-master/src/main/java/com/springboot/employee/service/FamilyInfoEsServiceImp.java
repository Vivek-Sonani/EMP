package com.springboot.employee.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.springboot.employee.repository.*;
import com.springboot.employee.model.FamilyInfo;
import com.springboot.employee.model.FamilyInfoDocument;

@Service
public class FamilyInfoEsServiceImp implements FamilyInfoEsService {

	@Autowired
	private FamilyInfoEsRepository familyInfoEsRepository;

	@Override
	public FamilyInfoDocument addFamilyinfo(FamilyInfo familyInfo) {
		FamilyInfoDocument familyInfoDocument = new FamilyInfoDocument(familyInfo);
		return familyInfoEsRepository.save(familyInfoDocument);
	}

}
