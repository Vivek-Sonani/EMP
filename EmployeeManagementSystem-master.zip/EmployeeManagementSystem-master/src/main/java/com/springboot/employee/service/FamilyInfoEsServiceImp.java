package com.springboot.employee.service;

import java.lang.StackWalker.Option;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.springboot.employee.repository.*;
import com.springboot.employee.model.FamilyInfo;
import com.springboot.employee.model.FamilyInfoDocument;

@Service
public class FamilyInfoEsServiceImp implements FamilyInfoEsService {

	@Autowired
	private FamilyInfoEsRepository familyInfoEsRepository;

	@Override
	public FamilyInfoDocument addFamilyinfo(FamilyInfo familyInfo) {
		FamilyInfoDocument familyInfoDocument = new FamilyInfoDocument(familyInfo);
		return familyInfoEsRepository.save(familyInfoDocument);
	}

	@Override
	public FamilyInfoDocument updateFamilyInfo(FamilyInfo familyInfo) {
		FamilyInfoDocument familyInfoDocument = new FamilyInfoDocument(familyInfo);
		return familyInfoEsRepository.save(familyInfoDocument);
	}

	@Override
	public FamilyInfoDocument getFamilyInfo(Integer id) {
		return familyInfoEsRepository.findById(id).get();
	}

	@Override
	public List<FamilyInfoDocument> getByEmployeeId(Integer employeeId) {
		return familyInfoEsRepository.findByEmployeeEmployId(employeeId);
	}

	@Override
	public void removeFamilyInfo(Integer id) {
		Optional<FamilyInfoDocument> familyInfoDocument=familyInfoEsRepository.findById(id);
		if(!familyInfoDocument.isEmpty()) {
		familyInfoEsRepository.deleteById(id);
		}else {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
		}

	}

}
