package com.springboot.employee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.employee.model.Employee;
import com.springboot.employee.model.EmployeeDocument;
import com.springboot.employee.repository.EmployeeEsRepository;

@Service
public class EmployeeEsServiceImp implements EmployeeEsService {
	@Autowired
	private EmployeeEsRepository employeeEsRepository;

	@Override
	public EmployeeDocument addEmployee(Employee employee) {
		EmployeeDocument employeeDocument = new EmployeeDocument(employee);
		return employeeEsRepository.save(employeeDocument);
	}

}
