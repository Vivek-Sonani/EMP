package com.springboot.employee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.employee.model.Address;
import com.springboot.employee.model.AddressDocument;
import com.springboot.employee.model.Employee;
import com.springboot.employee.model.EmployeeDocument;
import com.springboot.employee.repository.EmployeeEsRepository;

@Service
public class EmployeeEsServiceImp implements EmployeeEsService {
	@Autowired
	private EmployeeEsRepository employeeEsRepository;
	
	@Autowired
	private AddressEsService addressEsService;

	@Override
	public EmployeeDocument getEsEmployee(Integer id) {
		return employeeEsRepository.findById(id).get();
	}

	@Override
	public EmployeeDocument addEsEmployee(Employee employee) {
		EmployeeDocument employeeDocument = new EmployeeDocument(employee);
		return employeeEsRepository.save(employeeDocument);
	}

	@Override
	public void deleteEsEmployee(Integer id) {
		employeeEsRepository.deleteById(id);
	}

	@Override
	public EmployeeDocument updateEmployee(Employee employee) {
		EmployeeDocument employeeDocument = new EmployeeDocument(employee);
		//Address add = employeeDocument.getAddress();
		//addressEsService.updateAddress(employeeDocument.getAddress());
		return employeeEsRepository.save(employeeDocument);
	}

	@Override
	public Iterable<EmployeeDocument> getAllEsEmployee() {
		// TODO Auto-generated method stub
		//EmployeeDocument employeeDocument = new EmployeeDocument();
		Iterable<EmployeeDocument> employeeDocument =  employeeEsRepository.findAll();
		return employeeDocument;
	}

}
