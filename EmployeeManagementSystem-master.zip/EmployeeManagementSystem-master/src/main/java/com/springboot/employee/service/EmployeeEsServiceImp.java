package com.springboot.employee.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import com.springboot.employee.event.EmployeeCreatedEvent;
import com.springboot.employee.event.EmployeeDeletedEvent;
import com.springboot.employee.event.EmployeeUpdatedEvent;
import com.springboot.employee.event.FamilyInfoCreatedEvent;
import com.springboot.employee.event.FamilyInfoDeletedEvent;
import com.springboot.employee.event.FamilyInfoUpdatedEvent;
import com.springboot.employee.model.Address;
import com.springboot.employee.model.AddressDocument;
import com.springboot.employee.model.Employee;
import com.springboot.employee.model.Employeedocument;
import com.springboot.employee.repository.EmployeeEsRepository;
import com.springboot.employee.repository.EmployeeRepository;

@Service
public class EmployeeEsServiceImp implements EmployeeEsService {
	@Autowired
	private EmployeeEsRepository employeeEsRepository;

	@Autowired
	private AddressEsService addressEsService;

	@Autowired
	private EmployeeRepository employeeRepository;
	
	//@Autowired
	//ApplicationEventPublisherAware applicationEventPublisherAware;
	
	private static final Logger logger = LoggerFactory.getLogger(EmployeeEsServiceImp.class);

	@Override
	public Employeedocument getEsEmployee(Integer id) {
		return employeeEsRepository.findById(id).get();
	}

	@Override
	public void index(Integer emplyeeId) {
		// Read employee by id from Sql DB.
		logger.info("starting index method:");
		Employee employee = employeeRepository.findById(emplyeeId).get();
		// Transform sql employee to ES employee
		Employeedocument employeedocument = new Employeedocument(employee);
		// save es employee using employeeEsRepo
		employeeEsRepository.save(employeedocument);
		logger.info("end of index method");
	}

	@Override
	public void deleteEsEmployee(Integer id) {
		employeeEsRepository.deleteById(id);
	}

	@Override
	public Iterable<Employeedocument> getAllEsEmployee() {
		// event)
		// Employeedocument Employeedocument = new Employeedocument();
		Iterable<Employeedocument> Employeedocument = employeeEsRepository.findAll();
		return Employeedocument;
	}


	@Override
	public Employeedocument updateEmployee(Integer id) {
		logger.info("starting updateEmloyee method:");
		Employee employee = employeeRepository.findById(id).get();
		// Transform sql employee to ES employee
		Employeedocument employeedocument = new Employeedocument(employee);
		// save es employee using employeeEsRepo
		logger.info("end of updateEmployee method");
		return employeeEsRepository.save(employeedocument);
	}

	// TODO method1 : @EventListner void onEmployeeCreated(EmployeeCreatedEvent
	// event)
	// - index(event.getId());
	@EventListener
    public void onEmployeeCreated(EmployeeCreatedEvent event) {
        Integer employeeId = event.getEmployeeId();
        index(employeeId);
        logger.info("successfull....");
    }
	// print success log
	// TODO method2 : 13 onEmployeeUpdated
	@EventListener
    public void onEmployeeUpdated(EmployeeUpdatedEvent event) {
        Integer employeeId = event.getEmployeeId();
        updateEmployee(employeeId);
        logger.info("successfull....");
    }
	// TODO: method3 : onEMployeeDeleted
	// delete()
	@EventListener
    public void onEmployeeDeleted(EmployeeDeletedEvent event) {
        Integer employeeId = event.getEmployeeId();
        deleteEsEmployee(employeeId);
        logger.info("successfull....");
    }
	
	@EventListener
    public void onFamilyInfoCreated(FamilyInfoCreatedEvent event) {
        Integer employeeId = event.getEmployeeId();
        index(employeeId);
        logger.info("successfull....");
    }
	
	@EventListener
	public void onFamilyInfoUpdated(FamilyInfoUpdatedEvent event) {
		Integer id = event.getEmployeeId();
		index(id);
		logger.info("successfull...");

	}

	@EventListener
	public void onFamilyInfoDeleted(FamilyInfoDeletedEvent event) {
		Integer id = event.getEmployeeId();
		index(id);
		logger.info("successfull...");
	}
	
}
