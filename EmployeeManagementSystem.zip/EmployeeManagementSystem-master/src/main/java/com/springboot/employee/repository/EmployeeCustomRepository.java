//package com.springboot.employee.repository;
//
//import java.util.List;
//
//import org.springframework.stereotype.Repository;
//
//import com.springboot.employee.model.Employee;
//
//@Repository
//public interface EmployeeCustomRepository {
//
//	 public List<Employee> findByName(String firstname);
//}
