package com.springboot.employee.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.employee.model.Employeedocument;
import com.springboot.employee.model.FamilyInfoDocument;
import com.springboot.employee.repository.EmployeeEsRepository;
import com.springboot.employee.repository.FamilyInfoEsRepository;

@Service
public class ServiceEs {

	@Autowired
	private EmployeeEsRepository employeeEsRepository;

	@Autowired
	private FamilyInfoEsRepository familyInfoEsRepository;

	private static final Logger logger = LoggerFactory.getLogger(ServiceEs.class);

	public void logInfo() {
		logger.info("this is log info");
	}

	public void getEmployeeFull(Integer id) {
//		logger.info("starting ..");
//		Employeedocument employeedocument = employeeEsRepository.findById(id).get();
//		List<FamilyInfoDocument> list = familyInfoEsRepository.findByEmployeeId(id);
//		employeedocument.setFamilyInfo(list);
//		logger.info("end method...");
		// Employeedocument.setAddress();
	}

}
